#' @title Get some graphics for clonality analysis
#'
#' @description
#' Graphical visualization of the results
#'
#' @param LTR5.reads tibble. LTR3 reads loaded with
#' @param LTR3.reads tibble. LTR5 reads loaded with
#' @param sampleName character. Sample Name use to output the graphic
#' @param LTR.merged tibble. LTR merged reads
#'
#' @return A PDF graphic depicting various statistics
#'
#' @author Vincent Hahaut
#'
#' @examples
#'
#'
#' @export
exploreClonalityResults <- function(LTR5.reads = NULL, LTR3.reads = NULL, LTR.merged = NULL, sampleName = NULL){

  suppressPackageStartupMessages(library(dplyr))
  suppressPackageStartupMessages(library(ggplot2))
  suppressPackageStartupMessages(library(tibble))
  suppressPackageStartupMessages(library(readr))
  suppressPackageStartupMessages(library(stringr))
  suppressPackageStartupMessages(library(tidyr))

  # SOLO LTRs
  reads <- bind_rows(
    LTR5.reads$R1 %>% mutate(LTR = "LTR5", mate = "R1"),
    LTR5.reads$R2 %>% mutate(LTR = "LTR5", mate = "R2"),
    LTR3.reads$R1 %>% mutate(LTR = "LTR3", mate = "R1"),
    LTR3.reads$R2 %>% mutate(LTR = "LTR3", mate = "R2")
  )

  readCount.LTR <- reads %>%
    dplyr::filter(mate == "R1", isPRIMARY == TRUE) %>%
    group_by(LTR) %>%
    summarise(readCount = n() ) %>%
    ggplot(aes(x = LTR, y = readCount, fill = LTR)) +
    geom_bar(stat = "identity", color = "black") +
    theme_light() +
    ylab( "Number of reads") +
    theme( legend.position = "none")

  readCount.flag <- reads %>%
    dplyr::filter(isPRIMARY == TRUE) %>%
    group_by(LTR, flag) %>%
    summarise(readCount = n() ) %>%
    ggplot(aes(x = as.factor(flag), y = readCount, fill = as.factor(flag))) +
    geom_bar(stat = "identity", color = "black") +
    facet_wrap(~ LTR, scale = "free") +
    theme_light() +
    ylab( "Number of reads") +
    xlab( "SAM flags" )
    theme( legend.position = "none")

  insertSize.LTR5 <-
    bind_cols(
      LTR5.reads$R1 %>% mutate(LTR = "LTR5", mate = "R1", cigarSize = getCIGARsize(cigar)),
      LTR5.reads$R2 %>% mutate(LTR = "LTR5", mate = "R2", cigarSize = getCIGARsize(cigar))
    ) %>%
    dplyr::filter(isPRIMARY == TRUE) %>%
    mutate(insert = abs(pos - pos1 + cigarSize)) %>%
    select(LTR, mate, insert) %>%
    ggplot() +
    geom_histogram(aes(x = insert), binwidth = 5, color = "black", fill = "darkred") +
    scale_x_continuous(breaks = seq(0, 1000, 25)) +
    theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
    xlab("Insert Size (in bp)") +
    ylab("Number of reads") +
    ggtitle("Insert Size Approximation on PRIMARY alignment: LTR5")

  insertSize.LTR3 <-
    bind_cols(
      LTR3.reads$R1 %>% mutate(LTR = "LTR3", mate = "R1", cigarSize = getCIGARsize(cigar)),
      LTR3.reads$R2 %>% mutate(LTR = "LTR3", mate = "R2", cigarSize = getCIGARsize(cigar))
    ) %>%
    dplyr::filter(isPRIMARY == TRUE) %>%
    mutate(insert = abs(pos - pos1 + cigarSize)) %>%
    select(LTR, mate, insert) %>%
    ggplot() +
    geom_histogram(aes(x = insert), binwidth = 5 , color = "black", fill = "darkgreen") +
    scale_x_continuous(breaks = seq(0, 1000, 25)) +
    theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
    xlab("Insert Size (in bp)") +
    ylab("Number of reads") +
    ggtitle("Insert Size Approximation on PRIMARY alignment: LTR3")

  # MERGED LTRs
  pieChart <- LTR.merged %>%
    mutate(position = ifelse(p.LTR > 10, paste0(chr, ":", exactPosition), NA)) %>%
    ggplot( aes(x = "", y = filtered.STRINGENT.max, fill = position) ) +
    coord_polar("y", start=0) +
    geom_bar(width = 1, stat = "identity") +
    theme_void() +
    theme(legend.position = "none") +
    ggtitle(paste0("Integration Sites: ", sampleName))

  ggsave(plot = readCount.LTR, filename = paste0(sampleName, "-runInformations_readCount_LTR.pdf"), height = 4, width = 6)
  ggsave(plot = readCount.flag, filename = paste0(sampleName, "-runInformations_readCount_flag.pdf"), height = 4, width = 6)
  ggsave(plot = insertSize.LTR5, filename = paste0(sampleName, "-runInformations_insertSize_LTR5.pdf"), height = 4, width = 6)
  ggsave(plot = insertSize.LTR3, filename = paste0(sampleName, "-runInformations_insertSize_LTR3.pdf"), height = 4, width = 6)
  ggsave(plot = pieChart, filename = paste0(sampleName, "-pieChart_STRINGENT.pdf"), width = 10, height = 10)

}
