#' @title Get Read Size CIGAR
#'
#' @description
#' Given a CIGAR character string, returns a the length of the read
#'
#' @param cigar character. CIGAR code from SAM file
#'
#' @return integer. Length of the read
#'
#' @author Vincent Hahaut & Nicolas Rosewick
#'
#' @examples
#' getCIGARsize(cigar = "11S22M3D30S")
#'
#' @export
getCIGARsize <- function(cigar = NULL){

  # 1. Remove letters
  cigarNumbers <- gsub(x = cigar, pattern = "[A-Z]",replacement = " ")

  # 2. Return sum of the values
  return(
    sum(
      as.numeric(strsplit(cigarNumbers, " ")[[1]])
      )
  )
}

