#' @title Extract Integration Site Positions from SAM Files
#'
#' @description
#' Given SAM files (R1 and R2) processed by the clonality bash-script pipeline, \code{"extractISposition()"} extracts exact shear and integration sites of each reads
#' This process involves computing the TRUE read and soft-clipping lengths by exploring the CIGAR SAM field.
#' Reverse strand reads position is mainly impacted by this function (Position + readSize - Soft-Clipping - 1)
#' Shear sites are extracted from R2 reads positions
#' Viral orientation is gathered using SAM flags
#'
#' @param r1 tibble. R1 reads loaded using \code{"loadClonalityData()"} or \code{"loadClonalityDataMULTIMAPPING()"}
#' @param r2 tibble. R2 reads loaded using \code{"loadClonalityData()"} or \code{"loadClonalityDataMULTIMAPPING()"}
#' @param randomTag tibble. Two columns tibble containing random tag sequences ("randomTag") and read IDs ("read_id")
#' @param LTR character. LTR sequences currently processed ("LTR3" or "LTR5")
#' @param recall logical. TRUE or FALSE
#' @param ALTERN logical. Are you trying to map reads with several alternative positions per read_id ?

#' @return a tibble containing
#'
#' @author Vincent Hahaut & Nicolas Rosewick
#'
#' @examples
#' extractISposition(r1 = r1.LTR3.tidy, r2 = r2.LTR3.tidy, randomTag = randomTag, LTR = "LTR3", recall = FALSE)
#'
#' @export
extractISposition <- function(r1 = NULL, r2 = NULL, randomTag = NULL, LTR = NULL, ALTERN = NULL){

  suppressPackageStartupMessages(library(dplyr))
  suppressPackageStartupMessages(library(tibble))
  suppressPackageStartupMessages(library(stringr))

  # 1. Adjust IS position:
  # Corrects for soft-clipping
  # readSizeCigar = return length of the read based on cigar length (soft-clipping included)
  # splitCigar = return right and/or left softclipping length

  # New position is contained into "exactPosition"
  r1.adjusted <- r1 %>%
    mutate(strand = as.character(strand)) %>%
    rowwise() %>%
    mutate(exactPosition = ifelse(strand == "-", (pos + getCIGARsize(cigar) - sum(splitCigar(cigar)) - 1), pos)) %>%
    ungroup() %>%
    select(-pos)

  # 2. Adapt viral orientation based on SAM flags
  r1.adjusted <- r1.adjusted %>%
    mutate(LTR = LTR) %>%
    mutate(
      strand = case_when(
        LTR == "LTR5" & strand == "+" ~ "-",
        LTR == "LTR5" & strand == "-" ~ "+",
        LTR == "LTR3" ~ strand
        ),
      properPair = if_else(flag %in% c(83, 99, 147, 164), TRUE, FALSE)
    ) %>%
    select(-LTR)

  # 3. Combine results
  # R2 positions gives shearing positions ("shearSite")
  if(ALTERN == FALSE){
    r1_r2 <- left_join(
      r1.adjusted,
      r2 %>% mutate(shearSite = paste0(chr, ":", pos)) %>% select(read_id, shearSite),
      by = c("read_id" = "read_id")
    )
  } else if(ALTERN == TRUE){
    r1_r2 <- bind_cols(
      r1.adjusted,
      r2 %>% mutate(shearSite = paste0(chr, ":", pos)) %>% select(shearSite)
    )
  }

  # 4. Add RandomTags
  r1_r2.randomTag <- left_join(r1_r2, randomTag, by=c("read_id" = "read_id"))

  # 5. Tidy
  r1_r2.randomTag.tidy <- r1_r2.randomTag %>%
    dplyr::select(-cigar) %>%
    mutate(LTR = LTR)

  return(r1_r2.randomTag.tidy)

}
