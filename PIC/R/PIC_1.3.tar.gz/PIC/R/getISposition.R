#' @title Get IS and Compute their Raw/Filtered Abundances
#'
#' @description
#' For each read in a SAM file adjust the position using \code{"extractISposition"} then group close position within a 'maxgap' up/down window.
#' Raw reads are described as the number of read at a given position while filtered takes into account shear site and random tag to remove PCR duplicates.
#'
#' @param r1 tibble. R1 reads loaded using \code{"loadClonalityData()"} or \code{"loadClonalityDataMULTIMAPPING()"} functions
#' @param r2 tibble. R2 reads loaded using \code{"loadClonalityData()"} or \code{"loadClonalityDataMULTIMAPPING()"} functions
#' @param randomTag tibble. Two columns tibble containing random tag sequences ("randomTag") and read IDs ("read_id")
#' @param LTR character. LTR sequences currently processed ("LTR3" or "LTR5")
#' @param recall logical. TRUE or FALSE
#'
#' @return a tibble of Integration sites and associated abundances
#'
#' @author Vincent Hahaut & Nicolas Rosewick
#'
#' @examples
#' getISposition(r1 = r1.LTR3.tidy, r2 = r2.LTR3.tidy, randomTag = randomTag, LTR = "LTR3", recall = FALSE)
#'
#' @export
getISposition <- function(r1 = NULL, r2 = NULL, r1.altern = NULL, r2.altern = NULL, randomTag = NULL, LTR = "LTR3", recall = FALSE, maxgap = 75, winRecall = 150, mapq.val = 3, sampleName.args = NULL, SAVE = TRUE){

  suppressPackageStartupMessages(library(dplyr))
  suppressPackageStartupMessages(library(GenomicRanges))
  suppressPackageStartupMessages(library(tibble))
  suppressPackageStartupMessages(library(stringr))
  suppressPackageStartupMessages(library(readr))

  if(mapq.val < 3){
    print("WARNING: Mapq should not be lower than 3, will allow reads too dodgy !")
  }

  # 1. Compute the exact IS position for each reads
  if(SAVE == FALSE){

    IS.posFixed <- extractISposition(r1 = r1,
                                     r2 = r2,
                                     randomTag = randomTag,
                                     LTR = LTR,
                                     ALTERN = FALSE)
  } else {

    if(file.exists(paste0(sampleName.args, "_ISposFixed_QUAL_", LTR, ".txt"))){

      print(paste0("Found already saved file at: ", paste0(sampleName.args, "_ISposFixed_QUAL_", LTR, ".txt") , " use it"))
      suppressMessages(IS.posFixed <- read_delim(paste0(sampleName.args, "_ISposFixed_QUAL_", LTR, ".txt"), col_names = T, delim = "\t"))

    } else {

      print(paste0("No file found at: ", paste0(sampleName.args, "_ISposFixed_QUAL_", LTR, ".txt") , " create and save new one!"))

      IS.posFixed <- extractISposition(r1 = r1,
                                       r2 = r2,
                                       randomTag = randomTag,
                                       LTR = LTR,
                                       ALTERN = FALSE)

      write.table(IS.posFixed, paste0(sampleName.args, "_ISposFixed_QUAL_", LTR, ".txt"), sep = "\t", row.names = F, quote = F)

    }
  }


  print(paste0("ALL: ", length(unique(IS.posFixed$read_id)), " total number of unique reads"))
  print(paste0("PROPER-PAIRS: ", IS.posFixed %>% dplyr::filter(isPRIMARY == TRUE, properPair == TRUE, mapq >= 3) %>% nrow(), " reads reads in proper-pairs with mapq >= 3"))
  print(paste0("STRINGENT: ", IS.posFixed %>% dplyr::filter(isPRIMARY == TRUE, properPair == TRUE, mapq >= mapq.val) %>% nrow(), " reads in proper-pairs and mapq >= ", mapq.val))


  # 2. For every read, choose the best mapping
  # MAPQ in bowtie2: http://biofinysics.blogspot.com/2014/05/how-does-bowtie2-assign-mapq-scores.html
  # MAPQ >= 3 excludes multi-reads and keep low mismatches
  IS.posFixed.filter <- IS.posFixed %>%
    mutate(isSTRINGENT = mapq >= mapq.val) %>%
    mutate(stringency = paste0(properPair, ":", isSTRINGENT)) %>%
    dplyr::filter(mapq >= 3, isPRIMARY == TRUE)

  # 2. Add the number of raw/filtered reads
  # raw = number of reads sequenced for each position
  # filtered = number of unique dna molecule amplified ( ==> randomTags)
  IS.posFixed.counted <- IS.posFixed.filter %>%
    group_by(read_id) %>%
    group_by(chr, exactPosition, strand) %>%
    mutate(raw.ALL = n(),
           raw.PROPER = sum(properPair),
           raw.STRINGENT = sum(stringency == "TRUE:TRUE"),
           filtered.ALL = length(unique(paste(shearSite, randomTag))),
           filtered.PROPER = length(unique(paste(shearSite[properPair == TRUE], randomTag[properPair == TRUE]))),
           filtered.STRINGENT = length(unique(paste(shearSite[stringency == "TRUE:TRUE"], randomTag[stringency == "TRUE:TRUE"])))
           ) %>%
    ungroup()

  # 3. Cluster IS positions too close to be TRUE different IS
  # Look for each IS which are the other IS within a maxgap window (up/down).
  # Sum the number of reads (raw/filtered) found in each of them.
  # Reports the position of the one with the most filtered IS
  IS.posFixed.grouped <- IS.posFixed.counted %>%
    select(-flag, -read_id, -randomTag, -shearSite, -properPair, -N_ScoreLower, -stringency, -isSTRINGENT, -isPRIMARY, -numberAlignment, -AS, -XS, -mapq) %>%
    distinct() %>%
    mutate(readGroups = groupGenomicPositions(., maxgap = maxgap)) %>%
    group_by(readGroups) %>%
    mutate(groupedRawALL = sum(raw.ALL),
           groupedRawPROPER = sum(raw.PROPER),
           groupedRawSTRINGENT = sum(raw.STRINGENT),
           groupedFiltALL = sum(filtered.ALL),
           groupedFiltPROPER = sum(filtered.PROPER),
           groupedFiltSTRINGENT = sum(filtered.STRINGENT),
           weight = ifelse( groupedFiltPROPER == 0, 1, groupedFiltPROPER)
    ) %>%
    dplyr::filter(filtered.STRINGENT == max(filtered.STRINGENT)) %>%
    arrange(desc(filtered.STRINGENT)) %>%
    dplyr::slice(1) %>%
    ungroup() %>%
    select(-raw.ALL, -raw.PROPER, -raw.STRINGENT, -filtered.ALL, -filtered.PROPER, -filtered.STRINGENT, -readGroups, -weight) %>%
    dplyr::rename("raw.ALL" = groupedRawALL,
                  "raw.PROPER" = groupedRawPROPER,
                  "raw.STRINGENT" = groupedRawSTRINGENT,
                  "filtered.ALL" = groupedFiltALL,
                  "filtered.PROPER" = groupedFiltPROPER,
                  "filtered.STRINGENT" = groupedFiltSTRINGENT
                  ) %>%
    mutate(perc.ALL = round(filtered.ALL*100/sum(filtered.ALL), 3),
           perc.PROPER = round(filtered.PROPER*100/sum(filtered.PROPER), 3),
           perc.STRINGENT = round(filtered.STRINGENT*100/sum(filtered.STRINGENT), 3)) %>%
    arrange(desc(perc.ALL, filtered.ALL, raw.ALL))

  IS.final <- IS.posFixed.grouped

  # 4. Add recall information
  if(recall == TRUE){

    if(SAVE == FALSE){

      IS.posFixed.multi <- extractISposition(r1 = r1,
                                             r2 = r2,
                                             randomTag = randomTag,
                                             LTR = LTR,
                                             ALTERN = TRUE)
    } else {

      if(file.exists(paste0(sampleName.args, "_ISposFixed_RECALL_", LTR, ".txt"))){

        print(paste0("Found already saved file at: ", sampleName.args, "_ISposFixed_RECALL_", LTR, ".txt" , " use it"))
        suppressMessages(IS.posFixed.multi <- read_delim(paste0(sampleName.args, "_ISposFixed_RECALL_", LTR, ".txt"), col_names = T, delim = "\t"))

      } else {

        print(paste0("No file found at: ", paste0(sampleName.args, "_ISposFixed_RECALL_", LTR, ".txt") , "create and save new one!"))

        IS.posFixed.multi <- extractISposition(r1 = r1,
                                               r2 = r2,
                                               randomTag = randomTag,
                                               LTR = LTR,
                                               ALTERN = TRUE)

        write.table(IS.posFixed.multi, paste0(sampleName.args, "_ISposFixed_RECALL_", LTR, ".txt"), sep = "\t", row.names = F, quote = F)

      }
    }

    IS_ALL.gr <- makeGRangesFromDataFrame(IS.posFixed.multi,
                                             start.field = "exactPosition",
                                             end.field = "exactPosition",
                                             keep.extra.columns = T)

    IS_PROCESSED.gr <- makeGRangesFromDataFrame(IS.posFixed.grouped %>% filter(filtered.STRINGENT > 0),
                                      start.field = "exactPosition",
                                      end.field = "exactPosition",
                                      keep.extra.columns = T)

    overlaps <- findOverlaps(IS_PROCESSED.gr, IS_ALL.gr, maxgap = winRecall)

    # Randomly select reads for recall based on best-chance
    recall_IScounts <- overlaps %>%
      as_data_frame() %>%
      bind_cols(IS.posFixed[subjectHits(overlaps),],
                weigth = IS.posFixed.grouped$filtered.STRINGENT[queryHits(overlaps)]) %>%
      mutate(weigth = if_else(weigth == 0, as.numeric(1), as.numeric(weigth))) %>%
    # B. In case of multimapping, give the read to the window with the most filtered reads
      group_by(read_id) %>%
      dplyr::filter(weigth == max(weigth)) %>%
      arrange(desc(weigth)) %>%
      dplyr::slice(1) %>%
      ungroup() %>%
      # C. Compute raw read count
      group_by(queryHits) %>%
      mutate(raw.RECALL = n()) %>%
      # D. Compute filtered read count by removing PCR duplicats.
      mutate(filtered.RECALL = length(unique(paste0(queryHits, "-", shearSite, "-", randomTag)))) %>%
      ungroup() %>%
      # E. Tidying
      select(queryHits, raw.RECALL, filtered.RECALL) %>%
      distinct() %>%
      mutate(perc.RECALL = round(filtered.RECALL*100/sum(filtered.RECALL),3),
             queryHits = as.character(queryHits))

    # 3. Combine results to the IS table
    IS.final <- IS.posFixed.grouped %>%
      rownames_to_column("queryHits") %>%
      left_join(recall_IScounts,
                by = c("queryHits" = "queryHits")) %>%
      select(-queryHits) %>%
      arrange(desc(perc.ALL)) %>%
      mutate(chr = as.character(chr),
             perc.RECALL = ifelse(is.na(perc.RECALL), 0, perc.RECALL),
             raw.RECALL = ifelse(is.na(raw.RECALL), 0, raw.RECALL),
             filtered.RECALL = ifelse(is.na(filtered.RECALL), 0, filtered.RECALL)
      )

  }

  return(IS.final)

}
