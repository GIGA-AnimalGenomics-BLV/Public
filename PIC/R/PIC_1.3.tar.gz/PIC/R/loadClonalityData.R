#' @title Load R1/R2 SAM Files for Clonality Analysis
#'
#' @description
#' Load a BAM file for clonality data
#'
#' @param BAM.path character. Path to BAM file
#' @param isProperPair TRUE OR NA. Are only the proper pairs returned?
#' @param virus character. Name of the viral chromosome to exclude from analysis
#'
#' @return A list of two tibbles: R1 and R2
#'
#' @author Vincent Hahaut
#'
#' @examples
#' loadClonalityData(BAM.path = "my/path/R1_LTR3_candidateIS_bowtie2.bam", isProperPair = TRUE)
#'
#' @export
loadClonalityData <- function(BAM.path = NULL, isProperPair = NA, virus = NULL, mapq.val = NULL){

  if( file.info(BAM.path)$size > 0 ){

    suppressPackageStartupMessages(library(dplyr))
    suppressPackageStartupMessages(library(tibble))
    suppressPackageStartupMessages(library(Rsamtools))

    # 1. Load the file

    # 1.1. Process the R1:

    # PRIMARY
    R1.primary <- scanBam(file = BAM.path,
                  index = paste0(BAM.path, ".bai"),
                  param =
                    ScanBamParam(
                      what = c("qname", "flag", "rname", "pos", "mapq", "cigar", "strand"),
                      flag = scanBamFlag(
                        isProperPair = isProperPair,
                        hasUnmappedMate = FALSE,
                        isUnmappedQuery = FALSE,
                        isSecondaryAlignment = FALSE,
                        isFirstMateRead = TRUE
                      ),
                      tag=c("AS", "XS")
                    )
    )

    if( length(R1.primary[[1]]$qname) > 0 ){
      R1.primary <- data_frame(read_id = R1.primary[[1]]$qname,
                       flag = R1.primary[[1]]$flag,
                       chr = R1.primary[[1]]$rname,
                       pos = R1.primary[[1]]$pos,
                       mapq = R1.primary[[1]]$mapq,
                       cigar = R1.primary[[1]]$cigar,
                       strand = R1.primary[[1]]$strand,
                       AS = ifelse(is.null(R1.primary[[1]]$tag$AS), rep(0, length(R1.primary[[1]]$qname)), R1.primary[[1]]$tag$AS),
                       XS = ifelse(is.null(R1.primary[[1]]$tag$XS), rep(0, length(R1.primary[[1]]$qname)), R1.primary[[1]]$tag$XS)) %>%
        group_by(read_id) %>%
        mutate(isPRIMARY = TRUE, isSTRINGENT = mapq >= mapq.val) %>%
        ungroup()
    } else {
      R1.primary <- data_frame(read_id = character(),
                               flag = character(),
                               chr = character(),
                               pos = character(),
                               mapq = character(),
                               cigar = character(),
                               strand = character(),
                               AS = character(),
                               XS = character(),
                               isPRIMARY = character(),
                               isSTRINGENT = character())
    }


    # SECUNDARY
    R1.secundary <- scanBam(file = BAM.path,
                  index = paste0(BAM.path, ".bai"),
                  param =
                    ScanBamParam(
                      what = c("qname", "flag", "rname", "pos", "mapq", "cigar", "strand"),
                      flag = scanBamFlag(
                        isProperPair = isProperPair,
                        hasUnmappedMate = FALSE,
                        isUnmappedQuery = FALSE,
                        isSecondaryAlignment = TRUE,
                        isFirstMateRead = TRUE
                      ),
                      tag=c("AS", "XS")
                    )
    )

    if( length(R1.secundary[[1]]$qname) > 0){
      R1.secundary <- data_frame(read_id = R1.secundary[[1]]$qname,
                       flag = R1.secundary[[1]]$flag,
                       chr = R1.secundary[[1]]$rname,
                       pos = R1.secundary[[1]]$pos,
                       mapq = R1.secundary[[1]]$mapq,
                       cigar = R1.secundary[[1]]$cigar,
                       strand = R1.secundary[[1]]$strand,
                       AS = ifelse(is.null(R1.secundary[[1]]$tag$AS), rep(0, length(R1.secundary[[1]]$qname)), R1.secundary[[1]]$tag$AS),
                       XS = ifelse(is.null(R1.secundary[[1]]$tag$XS), rep(0, length(R1.secundary[[1]]$qname)), R1.secundary[[1]]$tag$XS)) %>%
        group_by(read_id) %>%
        mutate(isPRIMARY = FALSE, isSTRINGENT = mapq >= mapq.val) %>%
        ungroup()
    } else {
      R1.secundary <- data_frame(read_id = character(),
                                 flag = character(),
                                 chr = character(),
                                 pos = character(),
                                 mapq = character(),
                                 cigar = character(),
                                 strand = character(),
                                 AS = character(),
                                 XS = character(),
                                 isPRIMARY = character(),
                                 isSTRINGENT = character())
    }

    # GROUP
    R1 <- bind_rows(R1.primary, R1.secundary)

    if(nrow(R1) > 0){
      R1 <- R1 %>%
        group_by(read_id) %>%
        mutate(N_ScoreLower = sum(AS[isPRIMARY == TRUE] > AS[isPRIMARY == FALSE]),
               numberAlignment = n())  %>%
        ungroup()
    } else {
      R1 <- bind_cols(R1, data_frame(N_ScoreLower = character(), numberAlignment = character()))
    }

    # 1.2. Process R2:

    # PRIMARY
    R2.primary <- scanBam(file = BAM.path,
                  index = paste0(BAM.path, ".bai"),
                  param =
                    ScanBamParam(
                      what = c("qname", "flag", "rname", "pos", "mapq", "cigar", "strand"),
                      flag = scanBamFlag(
                        isProperPair = isProperPair,
                        hasUnmappedMate = FALSE,
                        isUnmappedQuery = FALSE,
                        isSecondaryAlignment = FALSE,
                        isFirstMateRead = FALSE
                      ),
                      tag=c("AS", "XS")
                    )
    )

    if( length(R2.primary[[1]]$qname) > 0){
      R2.primary <- data_frame(read_id = R2.primary[[1]]$qname,
                       flag = R2.primary[[1]]$flag,
                       chr = R2.primary[[1]]$rname,
                       pos = R2.primary[[1]]$pos,
                       mapq = R2.primary[[1]]$mapq,
                       cigar = R2.primary[[1]]$cigar,
                       strand = R2.primary[[1]]$strand,
                       AS = ifelse(is.null(R2.primary[[1]]$tag$AS), rep(0, length(R2.primary[[1]]$qname)), R2.primary[[1]]$tag$AS),
                       XS = ifelse(is.null(R2.primary[[1]]$tag$XS), rep(0, length(R2.primary[[1]]$qname)), R2.primary[[1]]$tag$XS)) %>%
      group_by(read_id) %>%
      mutate(isPRIMARY = TRUE, isSTRINGENT = mapq >= mapq.val) %>%
      ungroup()
    } else {
      R2.primary <- data_frame(read_id = character(),
                                 flag = character(),
                                 chr = character(),
                                 pos = character(),
                                 mapq = character(),
                                 cigar = character(),
                                 strand = character(),
                                 AS = character(),
                                 XS = character(),
                                 isPRIMARY = character(),
                                 isSTRINGENT = character())
    }

    # SECUNDARY
    R2.secundary <- scanBam(file = BAM.path,
                          index = paste0(BAM.path, ".bai"),
                          param =
                            ScanBamParam(
                              what = c("qname", "flag", "rname", "pos", "mapq", "cigar", "strand"),
                              flag = scanBamFlag(
                                isProperPair = isProperPair,
                                hasUnmappedMate = FALSE,
                                isUnmappedQuery = FALSE,
                                isSecondaryAlignment = TRUE,
                                isFirstMateRead = FALSE
                              ),
                              tag=c("AS", "XS")
                            )
    )

    if( length(R2.secundary[[1]]$qname) > 0){
      R2.secundary <- data_frame(read_id = R2.secundary[[1]]$qname,
                       flag = R2.secundary[[1]]$flag,
                       chr = R2.secundary[[1]]$rname,
                       pos = R2.secundary[[1]]$pos,
                       mapq = R2.secundary[[1]]$mapq,
                       cigar = R2.secundary[[1]]$cigar,
                       strand = R2.secundary[[1]]$strand,
                       AS = ifelse(is.null(R2.secundary[[1]]$tag$AS), rep(0, length(R2.secundary[[1]]$qname)), R2.secundary[[1]]$tag$AS),
                       XS = ifelse(is.null(R2.secundary[[1]]$tag$XS), rep(0, length(R2.secundary[[1]]$qname)), R2.secundary[[1]]$tag$XS)) %>%
        group_by(read_id) %>%
        mutate(isPRIMARY = FALSE, isSTRINGENT = mapq >= mapq.val) %>%
        ungroup()
    } else {
      R2.secundary <- data_frame(read_id = character(),
                                 flag = character(),
                                 chr = character(),
                                 pos = character(),
                                 mapq = character(),
                                 cigar = character(),
                                 strand = character(),
                                 AS = character(),
                                 XS = character(),
                                 isPRIMARY = character(),
                                 isSTRINGENT = character())

    }

    # GROUP
    R2 <- bind_rows(R2.primary, R2.secundary)

    if(nrow(R2) > 0){
      R2 <- R2 %>%
        group_by(read_id) %>%
        mutate(N_ScoreLower = sum(AS[isPRIMARY == TRUE] > AS[isPRIMARY == FALSE]),
               numberAlignment = n())  %>%
        ungroup()
    } else {
      R2 <- bind_cols(R2, data_frame(N_ScoreLower = character(), numberAlignment = character()))
    }

    # 2. Exclude viral reads
    R1 <- R1 %>%
      dplyr::filter(chr != virus)

    R2 <- R2 %>%
      dplyr::filter(chr != virus)

    # 3. Resynchronise pairs.
    # Chosen reads need to be paired. Unfortunately even after careful cleaning/triming some reads still tend to align to the provirus AND reference.
    # Such pairs need to be as the shear site cannot be evaluated
    # This option can be removed when using bowtie2 --no-mixed or chosing only proper pairs.
    R1 <- filter(R1, read_id %in% R2$read_id)
    R2 <- filter(R2, read_id %in% R1$read_id)

    # 4. Get Only provirus
    virus <- scanBam(file = BAM.path,
                            index = paste0(BAM.path, ".bai"),
                            param =
                              ScanBamParam(
                                what = c("qname", "flag", "rname", "pos", "mapq", "cigar", "strand"),
                                flag = scanBamFlag(
                                  isProperPair = NA,
                                  hasUnmappedMate = FALSE,
                                  isUnmappedQuery = FALSE,
                                  isSecondaryAlignment = FALSE,
                                  isFirstMateRead = TRUE
                                ),
                                which = GRanges(seqnames = virus, IRanges(start = 0, end = 100000))
                              )
    )

    if( length(virus[[1]]$qname) > 0){
      virus <- data_frame(read_id = virus[[1]]$qname,
                          flag = virus[[1]]$flag,
                          chr = virus[[1]]$rname,
                          pos = virus[[1]]$pos,
                          mapq = virus[[1]]$mapq,
                          cigar = virus[[1]]$cigar,
                          strand = virus[[1]]$strand) %>%
        dplyr::filter(mapq >= mapq.val)
    } else {
      virus <- data_frame(read_id = character(),
                 flag = character(),
                 chr = character(),
                 pos = character(),
                 mapq = character(),
                 cigar = character(),
                 strand = character())
    }

    return(list(R1 = R1, R2 = R2, virus = virus))

  } else {

    print("Empty Inputs: R1/R2 non-multimapped reads")

    return( list(R1=as_tibble(), R2=as_tibble()) )

  }


}
