#' @title Proviral Insertion Calling (PIC)
#'
#' @description
#' Wrapper function for the Proviral Integration Calling pipeline
#'
#' @param LTR3.args BAM file path. Path to the R1 LTR3 candidate reads
#' @param LTR5.args BAM file path. Path to the R2 LTR5 candidate reads
#' @param randomTag.args SAM file path. Path to random tags sequences (8 nucleotides)
#' @param sampleName.args character. Sample ID
#' @param geneBedFile.args character. Path to the geneInfos.sorted.txt file generated with clonality_indexBuilder.sh
#' @param rawFASTQ.args character. Path to the raw R1 or R2 FASTQ file (to get number of raw reads)
#' @param winRecall numeric. Recall distance up/dowstream of each well defined IS
#' @param virus.args charachter. Name of the viral chromosome (Ex: HTLV_ATK, BLV_YR2, ...)
#'
#' @return
#' Clonality tables: Merged or solo. Summary Graphics
#'
#' @author Vincent Hahaut
#'
#' @examples
#' PIC()
#'
#' @export
PIC <- function(
  LTR3.args = "4_read_hostAlign/LTR3_candidateIS_bowtie2_BEST.sorted.bam",
  LTR5.args = "4_read_hostAlign/LTR5_candidateIS_bowtie2_BEST.sorted.bam",
  LTR3.altern = "4_read_hostAlign/LTR3_candidateIS_bowtie2_ALTERN.sorted.bam",
  LTR5.altern = "4_read_hostAlign/LTR5_candidateIS_bowtie2_ALTERN.sorted.bam",
  randomTag.args = "5_randomTag/R2_randomTag.txt",
  sampleName.args = NA,
  geneBedFile.args = NA,
  rawFASTQ.args = "raw/R1.fastq",
  winRecall = 600,
  virus.args = NA,
  mapqSTRINGENT = 30){

  ## 0. Load the librairies:
  suppressPackageStartupMessages(library(dplyr))
  suppressPackageStartupMessages(library(ggplot2))
  suppressPackageStartupMessages(library(tibble))
  suppressPackageStartupMessages(library(readr))
  suppressPackageStartupMessages(library(WriteXLS))
  suppressPackageStartupMessages(library(ShortRead))
  suppressPackageStartupMessages(library(stringr))
  suppressPackageStartupMessages(library(tidyr))
  suppressPackageStartupMessages(library(GenomicRanges))
  suppressPackageStartupMessages(library(Rsamtools))

  print("1. ------ Load Arguments ------")

  args <- c(LTR3.args,
            LTR5.args,
            LTR3.altern,
            LTR5.altern,
            randomTag.args,
            sampleName.args,
            geneBedFile.args,
            rawFASTQ.args,
            virus.args)

  if(length(args) != 9){

    print("Missing Argument!")

  } else {

    # 1. Random Tags
    randomTag <- read_tsv(randomTag.args, col_names = c("read_id", "randomTag"))

    print("2. ------ LTR3 ------")

    print("Load LTR3 reads")
    LTR3.reads <- loadClonalityData(BAM.path = LTR3.args, virus = virus.args, isProperPair = NA, mapq.val = mapqSTRINGENT)
    #
    r1_LTR3.tidy <- LTR3.reads$R1
    r2_LTR3.tidy <- LTR3.reads$R2
    LTR3_provirus.tidy <- LTR3.reads$virus

    LTR3_altern.reads <- loadClonalityData(BAM.path = LTR3.altern, virus = virus.args, isProperPair = NA, mapq.val = mapqSTRINGENT)
    #
    r1_LTR3_altern.tidy <- LTR3_altern.reads$R1
    r2_LTR3_altern.tidy <- LTR3_altern.reads$R2

    if(nrow(r1_LTR3.tidy) > 0 & nrow(r2_LTR3.tidy) > 0){

      print("getISpositions")
      LTR3.positions <- getISposition(r1 = r1_LTR3.tidy,
                                      r2 = r2_LTR3.tidy,
                                      r1.altern = r1_LTR3_altern.tidy,
                                      r2.altern = r2_LTR3_altern.tidy,
                                      randomTag = randomTag,
                                      LTR = "LTR3",
                                      recall = TRUE,
                                      maxgap = 75,
                                      winRecall = winRecall,
                                      mapq.val = mapqSTRINGENT,
                                      sampleName.args = sampleName.args,
                                      SAVE = TRUE)

    } else {

      print(" ===> No reads detected, check inputs: SKIP LTR3' DETECTION")
      LTR3.positions <- tibble()

    }

    print("3. ------ LTR5 ------")

    print("Load non-multimapped reads")

    LTR5.reads <- loadClonalityData(BAM.path = LTR5.args, virus = virus.args, isProperPair = NA, mapq.val = mapqSTRINGENT)

    r1_LTR5.tidy <- LTR5.reads$R1
    r2_LTR5.tidy <- LTR5.reads$R2
    LTR5_provirus.tidy <- LTR5.reads$virus
    #
    LTR5_altern.reads <- loadClonalityData(BAM.path = LTR5.altern, virus = virus.args, isProperPair = NA, mapq.val = mapqSTRINGENT)
    #
    r1_LTR5_altern.tidy <- LTR5_altern.reads$R1
    r2_LTR5_altern.tidy <- LTR5_altern.reads$R2

    if(nrow(r1_LTR5.tidy) > 0 & nrow(r2_LTR5.tidy) > 0){

      print("getISpositions")
      LTR5.positions <- getISposition(r1 = r1_LTR5.tidy,
                                      r2 = r2_LTR5.tidy,
                                      r1.altern = r1_LTR5_altern.tidy,
                                      r2.altern = r2_LTR5_altern.tidy,
                                      randomTag = randomTag,
                                      LTR = "LTR5",
                                      recall = TRUE,
                                      maxgap = 75,
                                      winRecall = winRecall,
                                      mapq.val = mapqSTRINGENT,
                                      sampleName.args = sampleName.args,
                                      SAVE = TRUE)

    } else {

      print(" ===> No reads detected, check inputs: SKIP LTR5' DETECTION")
      LTR5.positions <- tibble()

    }

    print("4. ------ Group results ------")

    LTR.positions <- bind_rows(LTR3.positions, LTR5.positions)

    print("5. ------ Tidy and annotate results ------")

    print("Load Statistics Data")

    if(nrow(LTR.positions) > 0){

      print("Annotate results: Single")
      LTR.positions.annotated <- annotateIS(IS = LTR.positions,
                                            geneBedFile.path= geneBedFile.args,
                                            sample = sampleName.args)

      print("Merge LTR5-LTR3 results")
      LTR.merged <- mergeLTRs_V2(LTR.positions)

      print("Annotate results: Merged")
      LTR.merged.annotated <- annotateIS(IS = LTR.merged,
                                         geneBedFile.path = geneBedFile.args,
                                         sample = sampleName.args)

      LTR.merged.simplified <- select(LTR.merged.annotated,
                                      -raw.ALL.LTR5,
                                      -raw.ALL.LTR3,
                                      -filtered.ALL.LTR5,
                                      -filtered.ALL.LTR3,
                                      -raw.PROPER.LTR5,
                                      -raw.PROPER.LTR3,
                                      -filtered.PROPER.LTR5,
                                      -filtered.PROPER.LTR3) %>%
        dplyr::filter(filtered.STRINGENT.max > 0)

      print("Output final statistics")
      stats <- getStatistics(IS = LTR.merged.annotated,
                             r1 = rawFASTQ.args,
                             randomTag = randomTag,
                             pureViral_LTR5 = LTR5_provirus.tidy,
                             pureViral_LTR3 = LTR3_provirus.tidy)

      print("6. ------ Save Results ------")

      out.path <- paste0(sampleName.args, "-")

      # Clean the folder before writing:
      print("Remove previously written outputs")

      if( file.exists(paste0(out.path, "clonalityResults.txt")) ){
        file.remove(paste0(out.path, "clonalityResults.txt") )
      }
      if( file.exists(paste0(out.path, "mergedIS.txt")) ){
        file.remove(paste0(out.path, "mergedIS.txt") )
      }
      if( file.exists(paste0(out.path, "statistics.txt")) ){
        file.remove(paste0(out.path, "statistics.txt") )
      }

      print("Save results Txt Files")

      # 1. Before merging
      cat(paste0("# Date: ", Sys.time(), "\n"), file = paste0(out.path, "clonalityResults.txt"), append = TRUE)
      suppressWarnings(write.table(LTR.positions.annotated, paste(out.path,"clonalityResults.txt", sep=""),
                                   sep="\t", quote=F, row.names=F, col.names=T, append = TRUE))

      # 2. After merging
      cat(paste0("# Date: ", Sys.time(), "\n"), file = paste0(out.path, "mergedIS.txt"), append = TRUE)
      suppressWarnings(write.table(LTR.merged.annotated, paste(out.path,"mergedIS.txt", sep=""),
                                   sep="\t", quote=F, row.names=F, col.names=T, append = TRUE))

      # 3. Simplified output (merged)
      cat(paste0("# Date: ", Sys.time(), "\n"), file = paste0(out.path, "SIMPLIFIED_mergedIS.txt"), append = TRUE)
      suppressWarnings(write.table(LTR.merged.simplified, paste(out.path,"SIMPLIFIED_mergedIS.txt", sep=""),
                                   sep="\t", quote=F, row.names=F, col.names=T, append = TRUE))

      for(i in seq_along(stats)){
        write.table(stats[[i]], paste0(out.path, "statistics.txt"), sep = "\t", quote = F, row.names = F, col.names = F, append = T)
        cat("\n\n\n##############\n\n\n", file = paste0(out.path, "statistics.txt"), append = TRUE)
      }

      print("Save results XLS Files")
      xls1 <- paste(out.path, "mergedIS.xls", sep="")
      WriteXLS(list(LTR.positions.annotated, LTR.merged.annotated), xls1, SheetNames=c("resultSeparate", "mergeByLTR"))

    } else {

      out.path <- paste0(sampleName.args, "-")

      print("Output final statistics")
      stats <- getStatistics(IS = LTR.positions,
                             r1 = rawFASTQ.args,
                             randomTag = randomTag,
                             pureViral_LTR5 = LTR5_provirus.tidy,
                             pureViral_LTR3 = LTR3_provirus.tidy)

      print("Save results Txt Files")

      for(i in seq_along(stats)){
        write.table(stats[[i]], paste0(out.path, "statistics.txt"), sep = "\t", quote = F, row.names = F, col.names = F, append = T)
        cat("\n\n\n##############\n\n\n", file = "tables.csv", append = TRUE)
      }

      cat(paste0("# Date: ", Sys.time(), "\n"), file = paste0(out.path, "clonalityResults.xls"), append = TRUE)
      cat(paste0("# Date: ", Sys.time(), "\n"), file = paste0(out.path, "mergedIS.txt"), append = TRUE)

      print("Save results XLS Files")
      xls1 <- paste(out.path, "mergedIS.xls", sep="")
      WriteXLS(list(tibble("empty"), tibble("empty")), xls1, SheetNames=c("resultSeparate", "mergeByLTR"))

    }

  }
}
