#' @title Extract start/end position of each CIGAR code
#'
#' @description
#' Given a CIGAR character vector, extract the length of every CIGAR substring.
#' Can return a tibble containing start/end position of the substring length in the CIGAR, size of the substring (cumSum), read size and position regarding read length (left or right)
#'
#' @param cigar character. A CIGAR string
#' @param cigarLetter character. CIGAR code of interest ("all", "M", "I", "D", "N", "S", "H", "P" or "X")
#' @param simplify logical. If TRUE reports only start/end position of rightest and leftest selected letter positions.
#'
#' @return a vector c(start_leftest, end_rightest) or tibble with following fields: cigarLetters (CIGAR letter code), end (position of the substring in the CIGAR), start (position of the substring in the CIGAR), lengthSubstring (length of the motif in the read), cumSum (end of substring in the read), readSize, position (left/right).
#'
#' @author Vincent Hahaut & Nicolas Rosewick
#'
#' @examples
#' splitCigar(cigar = "11S120M1D18S", cigarLetter = "all", simplify = FALSE)
#' splitCigar(cigar = "11S120M1D18S", cigarLetter = "S", simplify = TRUE)
#'
#' @export
splitCigar <- function(cigar=NULL, cigarLetter = "S", simplify=TRUE){

  suppressPackageStartupMessages(library(stringr))
  suppressPackageStartupMessages(library(dplyr))
  suppressPackageStartupMessages(library(tibble))

  # 1. For each CIGAR code letter get position inside the CIGAR string
  cigarCode <- c("M", "I", "D", "N", "S", "H", "P", "X")
  softPos <- str_locate_all(cigar, cigarCode) %>%
    setNames(., cigarCode)

  if( length(softPos) > 0 ){

    # 2. Select only the start column
    # Start = end
    softPos <- lapply(softPos, function(x) as.data.frame(x)["end"])

    # 3. Combine all the elements into a dataframe:
    # cigarLetters: c("M", "I", "D", "N", "S", "H", "P", "X")
    # start: Start position of the read length substring for this letter
    # end: End position of the read length substring for this letter
    # lengthSubstring: Length of the substring attached to this letter
    # readSize: is the sum of each substrings
    # position: right or left (cumsum < readSize/2 = "left")
    # Filter based on the chosen letter or all of them
    softClippingPosistions <- do.call(rbind, softPos) %>%
      rownames_to_column("cigarLetters") %>%
      arrange(end) %>%
      mutate(cigarLetters = str_sub(string = cigarLetters, start = 1, end = 1),
             start = lag(end, default = 0) + 1,
             end = end - 1) %>%
      mutate(lengthSubstring = as.numeric(str_sub(start, end, string= cigar)),
             cumSum = cumsum(lengthSubstring),
             readSize = max(cumSum),
             position = ifelse(cumSum >= readSize/2, "right", "left")) %>%
      filter(
        ifelse(cigarLetter != "all", cigarLetters == cigarLetter,
               cigarLetters %in% c("M", "I", "D", "N", "S", "H", "P", "X"))
      )

    # 4. If simplify return a vector of the cigarLetters size at the rigthest and leftest
    # Else report the all table
    if(simplify == TRUE & cigarLetter != "all"){

      return(c(head(softClippingPosistions$lengthSubstring, 1),
               tail(softClippingPosistions$lengthSubstring, 1)))
    } else {

      return(softClippingPosistions)

    }

    # 5. In case cigar is empty
  } else {

    print("Empty CIGAR !!!!")

    if(simplify == TRUE  & cigarLetter != "all"){

      return(c(0,0))

    } else {

      return(tibble(cigarLetters=NULL, end=NULL, start=NULL, lengthSubstring=NULL, cumSum=NULL, readSize=NULL, position=NULL ))

    }
  }
}
