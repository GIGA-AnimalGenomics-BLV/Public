#' @title integrationSiteMotif
#'
#' @description
#' Get the a genomic sequence surrounding each IS
#'
#' @param IS dataframe. IS table after LTR3-LTR5 merge
#' @param win numeric. Window size
#' @param fasta fasta. Fasta file containing the reference sequence
#'
#' @return
#'
#' @author Vincent Hahaut
#'
#' @examples
#' integrationSiteMotif(IS = myIStable, win = 20, fasta = "path/to/genome.fasta")
#'
#' @export
integrationSiteMotif <- function(IS = NULL, win = 20, fasta = NULL){

  suppressPackageStartupMessages(library(Rsamtools))
  suppressPackageStartupMessages(library(tidyverse))
  suppressPackageStartupMessages(library(GenomicRanges))

  # 1. Read fasta file
  genomeSeq <- open(FaFile(fasta))

  # 2. Find for each IS the sequence up/down
  IS.gr <- IS %>%
    dplyr::select(seqnames, start, strand) %>%
    mutate(end = as.numeric(start) + win,
           start = as.numeric(ifelse(start < win, 1, start-win)))

  colnames(IS.gr) <- c("seqnames", "start", "strand", "end")
  IS.gr <- makeGRangesFromDataFrame(IS.gr)

  surrounding <- getSeq(genomeSeq, IS.gr)

  if(colnames(IS) %in% group){
    surrounding.matrix <- as_tibble(as.data.frame(surrounding)) %>% mutate(group=IS$group)
    surrounding.matrix <- split(surrounding.matrix, surrounding.matrix$group)
    surrounding.matrix$Ctrl <- NULL

    returned <- list()
    for(i in names(surrounding.matrix)){
      returned[[i]] <- surrounding.matrix[[i]]$x
    }

  } else {
    as_tibble(as.data.frame(surrounding)) %>%
      return()
  }

}
