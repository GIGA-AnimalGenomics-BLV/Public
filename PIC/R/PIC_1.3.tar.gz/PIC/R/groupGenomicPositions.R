#' @title Group Close Integration Sites
#'
#' @description
#' A two steps grouping function.
#' First take a GRanges group overlapping IS (within a 'maxgap' window).
#' Second look at overlap between each IS and those windows.
#' For each IS returns the ID of the window into which it falls.
#' NB: Strand information is taken into account
#'
#' @param genomicPositions tibble. A tibble containing at least a column "chr" and "exactPosition".
#' @param maxgap integer. During the creation of windows add this value up/down to look for close IS
#'
#' @return numerical vector. Numbers corresponds to the ID of the windows. Same IDs mean close IS that can be grouped.
#'
#' @author Vincent Hahaut & Nicolas Rosewick
#'
#' @examples
#' IS.posFixed <- extractISposition(r1 = r1, r2 = r2, randomTag = randomTag, LTR = LTR, recall = recall)
#' windowsGrouped <- groupGenomicPositions(IS.posFixed, maxgap = 25)
#'
#' @export
groupGenomicPositions <- function(genomicPositions = NULL, maxgap = 25){

  suppressPackageStartupMessages(library(GenomicRanges))
  suppressPackageStartupMessages(library(dplyr))
  suppressPackageStartupMessages(library(tibble))

  # 1. Transform the IS list into GRanges object
  positions.gr <- genomicPositions %>%
    dplyr::rename("seqnames" = chr, "start" = exactPosition) %>%
    mutate(end = start,
           strand = "*") %>%
    makeGRangesFromDataFrame(seqnames.field = "seqnames",
                             start.field = "start",
                             end.field = "end",
                             keep.extra.columns = T)

  # 2. Group close overlaping IS taken into account a up/down window
  windows <- GenomicRanges::reduce(positions.gr + maxgap)

  # 3. Find overlaps
  overlap <- findOverlaps(positions.gr, windows, maxgap = maxgap)

  # 4. Reports for each IS the window into which it is falling
  return(subjectHits(overlap))

}
