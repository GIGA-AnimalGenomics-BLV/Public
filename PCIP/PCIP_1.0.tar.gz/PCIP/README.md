# GENERAL WORKFLOW

<p align="center">
  <img src="https://github.com/GIGA-AnimalGenomics-BLV/Public/blob/master/PCIP/WORKFLOW/WORKFLOW.jpeg">
</p>

# PCIP_FILTER

<p align="center">
  <img src="https://github.com/GIGA-AnimalGenomics-BLV/Public/blob/master/PCIP/WORKFLOW/FILTER.jpeg">
</p>

# PCIP_GETBREAKPOINTS

<p align="center">
  <img src="https://github.com/GIGA-AnimalGenomics-BLV/Public/blob/master/PCIP/WORKFLOW/BREAKPOINTS.jpeg">
</p>

# PCIP_SUMMARISE

<p align="center">
  <img src="https://github.com/GIGA-AnimalGenomics-BLV/Public/blob/master/PCIP/WORKFLOW/SUMMARISE.jpeg">
</p>
