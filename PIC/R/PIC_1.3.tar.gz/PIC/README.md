# PIC

## Description 

Proviral Integration Calling (PIC) package is designed to gather proviral integration sites (IS) from clonality libraries after processing by the pipeline displayed at [Mapping & cleaning pipeline]().

## Installation

Currently the easiest way to install it is to download the MAC-compiled version (PIC_1.2.tar.gz) and run in your terminal:

```
R CMD INSTALL PIC_1.2.tar.gz
```

## Prerequists

* R >= 3.2
	* dplyr (>= 0.7.6)
	* ggplot2 (>= 2.2.1)
	* tibble (>= 1.4.2)
	* readr (>= 1.1.1)
	* WriteXLS (>= 4.0.0)
	* ShortRead (>= 1.3)
	* stringr (>= 1.3)
	* tidyr (>= 0.8)
	* Rsamtools (>= )
	* GenomicRanges (>= 1.32.2)
	 
## Inputs

R1/R2 BEST candidates IS, BAM files.

```
LTR3.args = "LTR3_candidateIS_bowtie2_BEST.sorted.bam",
LTR5.args = "LTR5_candidateIS_bowtie2_BEST.sorted.bam",
```

R1/R2 ALTERNATIVE candidates IS, BAM file

```
LTR3.altern = "LTR3_candidateIS_bowtie2_ALTERN.sorted.bam",
LTR5.altern = "LTR5_candidateIS_bowtie2_ALTERN.sorted.bam",
```

Random tags, txt file ($1: read ids, $2 random tag sequences)

```
randomTag.args = "R2_randomTag.txt"
```

Raw R1 FASTQ files (for statistics)
```
rawFASTQ.args = "R1.fastq"
```

Sample variables. Virus.args requires the name of the viral chromosome, sampleName.args the sample ID and geneBedFile the bed-like file required to annotate the results.
```
sampleName.args = NA
geneBedFile.args = NA
virus.args = NA
```

Stringency criteria: Minimal mapping quality (currently between 23 and 30 is adviced)

```
mapqSTRINGENT = 30
```
 


## Functions

All the functions to call IS are conveniently wrapped inside the PIC() function. Running:


```
PIC(
  LTR3.args = LTR3.args,
  LTR5.args = LTR5.args,
  LTR3.altern = LTR3.altern,
  LTR5.altern = LTR5.altern,
  randomTag.args = randomTag.args,
  sampleName.args = sampleName.args,
  geneBedFile.args = geneBedFile.args,
  rawFASTQ.args = rawFASTQ.args,
  virus.args = virus.args,
  mapqSTRINGENT = 30)
```

## Output

* "mySample_clonalityResults.txt"
	* IS and associated abundances, before merging close LTRs

* "mySample_mergedIS.txt"
	* IS and associated abundances, all reads used to detected IS, after merging close LTRs
	
* "mySample_SIMPLIFIED_mergedIS.txt"
	* IS and associated abundances, only most stringent reads reported, after merging close LTRs

* "mySample__ISposFixed_QUAL_LTR3.txt"
	* File containing the IS, shearSite, randomTag and associated values of every reads after processing with ```extractISposition()```
	
* "mySample__ISposFixed_QUAL_LTR5.txt"
	* File containing the IS, shearSite, randomTag and associated values of every reads after processing wit ```extractISposition()```

* "mySample_statistics.txt"
	* Run statistics (raw reads, number cells detected, ...)

* "mySample_mergedIS.xls"
	* To share with no bioinformaticians, a .xls containing merged and non-merged IS is also provided

	
## Details

Inside the hood ```PIC()``` calls several functions. You can find a step-by-step description of each of them by looking at the ./R folder associated to PIC package.

#### 1. Load random tags

```
randomTag <- read.table(randomTag.args, sep="\t", as.is=T) %>%
        as_tibble() %>%
        dplyr::rename("read_id" = V1, "randomTag" = V2)
```

#### 2. Process LTR3 reads

```loadClonalityData()``` takes BAM files as input. First it select mapped reads with a mapped mate and split them between first vs second in pairs and primary vs secundary alignments. Annotations are added to every read: mapq quality superior to the thresold and number of alternative mapping.

##### 2.1. Load LTR3 BEST reads

```
LTR3.reads <- loadClonalityData(BAM.path = LTR3.args, virus = virus.args, isProperPair = NA, mapq.val = mapqSTRINGENT)

r1_LTR3.tidy <- nonMultimapped$R1
r2_LTR3.tidy <- nonMultimapped$R2
LTR3_provirus.tidy <- LTR3.reads$virus
```

##### 2.2. Load LTR3 ALTERN reads
```
LTR3_altern.reads <- loadClonalityData(BAM.path = LTR3.altern, virus = virus.args, isProperPair = NA, mapq.val = mapqSTRINGENT)

r1_LTR3_altern.tidy <- LTR3_altern.reads$R1
r2_LTR3_altern.tidy <- LTR3_altern.reads$R2
```

##### 2.3. Get the LTR3 IS position of each reads

Viral-host junctions are extracted using ```extractISposition()```. End of the reads and soft-clipping are taken into as well as read orientions. Shear site and random tags are added. 
 
```getISposition()``` is divided in three parts. 

##### 2.3.1. Grouping reads:

First the reads are grouped by common integration sites. Due to potential mapping errors, groups of reads within a ```maxgap``` windows are grouped together. Only the position of the IS with the most mapped reads is reported. 

##### 2.3.2. Abundance:

The number of reads is first computed as the total number of reads supporting each integration site (**RAW ABUNDANCE**). PCR duplicates are removed by collapsing reads displaying the same shear site and random tag. The number of reads supporting each IS after removing PCR duplicates is the **FILTERED ABUNDANCE**.

We currently report 3 different values in this script. 

* ALL: Integration sites called using all the reads with a mapping quality >= 3.
* PROPER: Integration sites called using reads with a mapping quality >= 3 and mapped in proper-pairs.
* STRINGENT: Integration sites called using the reads with a mapping quality >= ```mapqSTRINGENT``` and mapped in proper-pairs.

##### 2.3.3. Recall: 

Some IS located in low complexity regions might be missed by main pipeline. In order to still take them into account we use a two-pass procedure:

1. First look at the IS supported by STRINGENT reads.
2. Consider all the alternative read mapping (Ex: bowtie2 -k 11) and compute the IS abundance with them. Reads are attributed to their correspoding IS based on their original IS abundance. If a read can be attributed to two IS, it will be given to the one supported by the most STRINGENT reads.


```
LTR3.positions <- getISposition(
r1 = r1_LTR3.tidy,
r2 = r2_LTR3.tidy,
r1.altern = r1_LTR3_altern.tidy,
r2.altern = r2_LTR3_altern.tidy,
randomTag = randomTag,
LTR = "LTR3",
recall = TRUE,
maxgap = 75,
winRecall = 150,
mapq.val = mapqSTRINGENT,
sampleName.args = sampleName.args,
SAVE = TRUE)
```

```

#### 3. Process LTR5 reads

LTR3 procedure is simply repeated by setting LTR = "LTR5". 

#### 4. Combine LTR5-LTR3
 
```
LTR.positions <- bind_rows(LTR3.positions.recall, LTR5.positions.recall)
```

##### 4.1. Annotate LTRs results

Annotation will provide information about the viral-host junction's position in the genome (genic, intergenic, closest upstream/downstream gene) and the orientation of the provirus against the genome (concordant or discordant). 

```
LTR.positions.annotated <- annotateIS(IS = LTR.positions, geneBedFile.path= geneBedFile.args, sample = sampleName.args)
```

#### 5. Merge close LTR5-LTR3

Close viral-junctions, detected by their LTR5 and LTR3, are combined into one viral-host junction. 

```
LTR.merged <- mergeLTRs_V2(LTR.positions, maxgap = 25)
```

##### 5.1. Annotate LTR5-LTR3 merged results
```
LTR.merged.annotated <- annotateIS(IS = LTR.merged, geneBedFile.path = geneBedFile.args, sample = sampleName.args)
```

#### 6. Get run statistics

Provide useful statistics such as number of integration sites, raw reads, number infected cells, ...

```
stats <- getStatistics(IS = LTR.merged.annotated, r1 = rawFASTQ.args, randomTag = randomTag, pureViral_LTR5.path = PureViral_LTR5.args, pureViral_LTR3.path = PureViral_LTR3.args)
```

#### 7. Save results 
```
out.path <- paste0(sampleName.args, "-")

# Clean the folder before writing:
print("Remove previously written outputs")

if( file.exists(paste0(out.path, "clonalityResults.txt")) ){
	file.remove(paste0(out.path, "clonalityResults.txt") )
}
if( file.exists(paste0(out.path, "mergedIS.txt")) ){
	file.remove(paste0(out.path, "mergedIS.txt") )
}
if( file.exists(paste0(out.path, "statistics.txt")) ){
	file.remove(paste0(out.path, "statistics.txt") )
}

# 1. Before merging
cat(paste0("# Date: ", Sys.time(), "\n"), file = paste0(out.path, "clonalityResults.txt"), append = TRUE)
suppressWarnings(write.table(LTR.positions.annotated, paste(out.path,"clonalityResults.txt", sep=""), sep="\t", quote=F, row.names=F, col.names=T, append = TRUE))

# 2. After merging
cat(paste0("# Date: ", Sys.time(), "\n"), file = paste0(out.path, "mergedIS.txt"), append = TRUE) 
suppressWarnings(write.table(LTR.merged.annotated, paste(out.path,"mergedIS.txt", sep=""), sep="\t", quote=F, row.names=F, col.names=T, append = TRUE))

# 3. Simplified output (merged)
cat(paste0("# Date: ", Sys.time(), "\n"), file = paste0(out.path, "SIMPLIFIED_mergedIS.txt"), append = TRUE)
suppressWarnings(write.table(LTR.merged.simplified, paste(out.path,"SIMPLIFIED_mergedIS.txt", sep=""), sep="\t", quote=F, row.names=F, col.names=T, append = TRUE))

for(i in seq_along(stats)){
write.table(stats[[i]], paste0(out.path, "statistics.txt"), sep = "\t", quote = F, row.names = F, col.names = F, append = T) 
cat("\n\n\n##############\n\n\n", file = paste0(out.path, "statistics.txt"), append = TRUE)
}

print("Save results XLS Files")
xls1 <- paste(out.path, "mergedIS.xls", sep="")
WriteXLS(list(LTR.positions.annotated, LTR.merged.annotated), xls1, SheetNames=c("resultSeparate", "mergeByLTR"))

```

