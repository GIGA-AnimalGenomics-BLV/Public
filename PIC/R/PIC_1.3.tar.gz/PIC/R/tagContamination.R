#' @title Tag contaminations in clonality data
#'
#' @description
#' Identify cross-contaminations and non-specific amplifications in NGS clonality datasets.
#' Rosewick et al 2017
#'
#' @param IS IS table. Generated with PIC::PIC() or containing the following columns: seqnames (IS chromosome), start (IS position), filtered.max (read count), ID (individual's name), sample (library ID).
#' @param maxOcc numeric. Percentage of sample contaminated by a IS to declare it "non-specific"
#' @param filt.recurrence. Numeric. Threshold on the shannon entropy to find an owner based on the IS recurrence
#' @param filt.abundance. Numeric. Threshold on the shannon entropy to find an owner based on the IS abundance
#' @param mapgap. Numeric. Distance up/down to cluster close IS from different samples
#' @param nonSpecific. Numeric. Declare an IS as non-specific if it is present in > nonSpecific of samples (%)
#' @param report Boolean. If TRUE, return the information table, summarising recurrence/abundance per IS, If FALSE, report the IS table flagged
#' @param minReadMax Numeric. Among the maximum number of reads per sample, needs at least minReadMax to check for filt.abundance
#'
#' @return
#' IS table annotated with categories
#'
#' @author
#' Vincent Hahaut
#'
#' @examples
#' tagContamination()
#'
#' @export
tagContamination <- function(IS = NULL, nonSpecific = 6, filt.recurrence = 0.85, filt.abundance = 0.85, minReadMax = 5, mapgap = 0, report = FALSE){

  suppressPackageStartupMessages(library(tidyverse))
  suppressPackageStartupMessages(library(entropy))
  suppressPackageStartupMessages(library(GenomicRanges))

  if(is.null(IS)){stop("IS parameter is empty, please provide an IS table")}
  if(nrow(IS) == 0){stop("IS parameter is empty, please provide an IS table")}
  if(!all(colnames(IS) %in% c("seqnames", "start", "filtered.max", "ID", "sample"))){
    stop("IS must contains the following columns: seqnames (IS chromosome), start (IS position), filtered.max (read count), ID (individual's name), sample (library ID)")}

  cat("Following parameters chosen \n",
      paste0("Percentage sample contaminated to call 'NON-SPECIFIC': ", nonSpecific, "%"), "\n",
      paste0("Entropy parameters for 'RECURRENCE': ", filt.recurrence), "\n",
      paste0("Entropy parameters for 'ABUNDANCE': ", filt.abundance), "\n",
      paste0("Minimum number reads among all samples to look for the 'ABUNDANCE' parameter: ", minReadMax), "\n",
      paste0("Cluster IS located within a ", mapgap, "bp window (up/down)"), "\n"
  )

  # 1. GROUP CLOSE IS
  # Sometimes, mapping errors, detection of LTR5 but not LTR3 etc can create small differences in the IS call even if it's the same IS
  # Group IS within a small window up/down (INDEX)
  IS.gr <- IS %>%
    mutate(end = start + mapgap) %>%
    makeGRangesFromDataFrame(seqnames.field = "seqnames",
                             start.field = "start",
                             end.field = "end",
                             ignore.strand = TRUE,
                             keep.extra.columns = T)

  wins <- GenomicRanges::reduce(IS.gr)
  overlaps <- findOverlaps(IS.gr, wins)
  IS.index <- mutate(IS, index = subjectHits(overlaps))

  # 2. COMPUTE RECURRENCE AND ABUNDANCE
  IS.index <- IS.index %>%
    group_by(index) %>%
    # In how many different samples ?
    mutate(numberSample = length(unique(sample)),
           numberIndividuals = length(unique(ID))) %>%
    group_by(index, ID) %>%
    # Compute the recurrence and max abundance
    summarise(
      reccurence = length(index),
      max.abundance = max(filtered.max),
      numberSample = unique(numberSample),
      numberIndividuals = unique(numberIndividuals),
    ) %>%
    # Compute the entropy of both parameters
    group_by(index) %>%
    mutate(
      max.recurrence = max(reccurence),
      e.recurrence = entropy(reccurence, unit = "log2"),
      recurrence.vec = list(reccurence),
      e.abundance = entropy(max.abundance, unit = "log2"),
      abundance.vec = list(max.abundance)
    )

  # 3. Attribute IS a different category:
  # NON-SPECIFIC: Over-recurrent IS, potentially arising from non-specific amplification of the genome
  # ENTROPY: IS that can be attributed to one individual based on distribution bias
  # else DUBIOUS:
  totalSample <- length(unique(IS$sample))

  IS.decision <- IS.index %>%
    group_by(index) %>%
    # Get the number max filtered among all and if IS is unique
    mutate(max.max.abundance = max(max.abundance),
           max.recurrence = max(reccurence),
           uniqueSp = all(numberIndividuals == 1)) %>%
    ungroup() %>%
    select(index, uniqueSp, max.max.abundance, e.abundance, max.recurrence, e.recurrence, numberSample, numberIndividuals) %>%
    distinct() %>%
    # Add categories
    mutate(
      CATEGORY = "DUBIOUS",
      CATEGORY = ifelse(uniqueSp == TRUE, "UNIQUE", CATEGORY),
      CATEGORY = ifelse(numberSample > (nonSpecific/100) * totalSample, "NON_SPECIFIC", CATEGORY),
      CATEGORY = ifelse(CATEGORY != "UNIQUE" & CATEGORY != "NON_SPECIFIC" & max.max.abundance > minReadMax & e.abundance < filt.abundance, "ENTROPY_ABUNDANCE", CATEGORY),
      CATEGORY = ifelse(CATEGORY != "UNIQUE" & CATEGORY != "NON_SPECIFIC" & max.recurrence > 1 & e.recurrence < filt.recurrence, "ENTROPY_RECURRENCE", CATEGORY)
    )

  # 4. Add the right owner
  IS.owner <- IS.index %>%
    left_join(IS.decision %>%
                select(index, CATEGORY), by = "index") %>%
    group_by(index) %>%
    mutate(
      OWNER = NA_character_,
      OWNER = ifelse(unique(CATEGORY) == "UNIQUE", as.character(ID), OWNER),
      OWNER = ifelse(unique(CATEGORY) == "ENTROPY_ABUNDANCE" , as.character(ID[max.abundance == max(max.abundance)])[1], OWNER), # [1] in case of egality
      OWNER = ifelse(unique(CATEGORY) == "ENTROPY_RECURRENCE", as.character(ID[reccurence == max(reccurence)])[1], OWNER) # [1] in case of egality
    ) %>%
    # Add the IS it corresponds to
    left_join(
      tibble(IS = paste0(IS.gr), index = 1:length(IS.gr)),
      by = c("index")
    )

  # 5. Return information table
  if(report == FALSE){

    IS.final <- IS %>%
      mutate(index = subjectHits(overlaps)) %>%
      left_join(IS.owner %>%
                  select(index, CATEGORY, OWNER) %>%
                  distinct(), by = c("index" = "index")) %>%
      select(-index)

    return(IS.final)

  } else {

    IS.final <- IS.index %>%
      left_join(
        tibble(IS = paste0(IS.gr), index = 1:length(IS.gr)),
        by = c("index")
      )
    return(IS.final)

  }
}
